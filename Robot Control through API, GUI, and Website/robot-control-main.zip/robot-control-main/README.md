# Robot Control

Creation of a System Debug Interface that allows users to view logs from the UI and results from the robot API, observe live feed from the robot's camera, and send actions to the robot. The live feed should have a compass overlaid that displays current and previous direction of travel.
