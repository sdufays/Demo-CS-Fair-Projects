class ImageConstant {
  static String imgUndrawsignin = 'assets/images/Welcome_pic.png';

  static String imgCheckmark15X15 = 'assets/images/img_checkmark_15X15.svg';

  static String imgSettings = 'assets/images/img_settings.svg';

  static String imgPlay = 'assets/images/img_play.svg';

  static String imgIllustration = 'assets/images/splashscreen_pic.svg';

  static String imgEdit = 'assets/images/img_edit.svg';

  static String imgCheckmark = 'assets/images/img_checkmark.svg';

  static String imgHome = 'assets/images/img_home.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
