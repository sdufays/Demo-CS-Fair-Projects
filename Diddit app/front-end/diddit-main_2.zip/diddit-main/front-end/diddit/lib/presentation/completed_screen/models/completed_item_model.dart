class CompletedItemModel {}
