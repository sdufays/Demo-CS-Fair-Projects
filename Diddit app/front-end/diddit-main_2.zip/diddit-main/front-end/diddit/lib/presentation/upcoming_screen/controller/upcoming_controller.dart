import '/core/app_export.dart';
import 'package:diddit_final/presentation/upcoming_screen/models/upcoming_model.dart';

class UpcomingController extends GetxController {
  Rx<UpcomingModel> upcomingModelObj = UpcomingModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
