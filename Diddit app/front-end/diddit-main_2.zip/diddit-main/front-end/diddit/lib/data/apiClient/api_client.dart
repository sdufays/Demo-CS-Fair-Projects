import 'package:diddit_final/core/app_export.dart';

class ApiClient extends GetConnect {}
