package com.didditfinal.diddit3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
