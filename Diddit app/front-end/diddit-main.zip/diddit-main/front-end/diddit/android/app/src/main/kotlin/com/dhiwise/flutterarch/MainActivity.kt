package com.didditfinal.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
